**To get information about a resource**

Command::

  aws apigateway get-resource --rest-api-id 1234123412 --resource-id zwo0y3

Output::

  {
      "path": "/path", 
      "pathPart": "path", 
      "id": "zwo0y3", 
      "parentId": "uyokt6ij2g"
  }
